package org.signify.OnlineContactManagementSystem.controller;

import org.signify.OnlineContactManagementSystem.entity.OnlineContactManagementSystem;
import org.signify.OnlineContactManagementSystem.services.OnlineContactManagementSystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/users")
public class OnlineContactManagementSystemController {

    @Autowired
    private OnlineContactManagementSystemService onlineContactManagementSystemService;

    @PostMapping("")
        public OnlineContactManagementSystem saveContactDetails(@RequestBody OnlineContactManagementSystem onlineContactManagementSystem){
        return onlineContactManagementSystemService.saveContactDetail(onlineContactManagementSystem);
    }

    @GetMapping("/{id}")
    public OnlineContactManagementSystem getAllContactDetailsById(@PathVariable("id") long userId){
        return onlineContactManagementSystemService.getContactDetailById(userId);

    }

    @PutMapping("/{id}")
    public OnlineContactManagementSystem updateContactDetails(@PathVariable("id") long userId, @RequestBody OnlineContactManagementSystem onlineContactManagementSystem){
        return onlineContactManagementSystemService.updateContactDetail(userId,onlineContactManagementSystem);
    }

    @DeleteMapping("/{id}")
    public String deleteContactDetailsById(@PathVariable("id") long userId){
        onlineContactManagementSystemService.deleteContactDetailById(userId);
        return "Contact Detail is deleted successfully";
    }

}
